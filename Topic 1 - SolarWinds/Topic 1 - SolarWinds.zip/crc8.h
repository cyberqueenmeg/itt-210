#pragma once

char crc8(const char* data, int length);
