
#include "crc8.h"
#include <string.h>
#include <stdio.h>


int main() {
   char* data = "For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast.";
   char* data2 = "exploitc2.ioFor by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast.";

   char sum = crc8(data, strlen(data));
   char sum2 = crc8(data2, strlen(data2));
   printf("Checksum is: 0x%0X\n", sum);
   printf("Checksum is: 0x%0X\n", sum2);

   if(sum == sum2) {
	   printf("This binary is exploited.");

   } else {
	   printf("This binary is clean.");
   }
   return 0;

}
